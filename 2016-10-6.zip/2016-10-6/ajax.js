function ajax(json){
	var settings = {
		url:json.url||'',
		data:json.data || {},
		dataType:json.dataType || 'json',
		type:json.type || 'get',
		succ:json.succ || function(){},
		fail:json.fail || function(){}
	};
	var toSting = Object.prototype.toString;
	for(var attr in json){
		if(toSting.call(json[attr]) === toSting.call(settings[attr])){
			settings[attr] = json[attr];
		}
	}
	
	var ajax = new XMLHttpRequest();
	var arr = [];
	settings.data.JQ = new Date().getTime();
	for(var key in settings.data){
		arr.push(key+'='+settings.data[key]);
	}
	
	settings.data = arr.join('&');
	
	//console.log(settings.url+'?'+encodeURI(settings.data))
	
	if(settings.type == 'get'){
		ajax.open('get',settings.url+'?'+encodeURI(settings.data),true);
		ajax.send();
	}else{
		ajax.open('get',settings.url,true);
		ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		ajax.send(settings.data);
	}
	
	ajax.onload = function(){
		if(ajax.status >= 200 || ajax.status <= 207){
			if(settings.dataType == 'json'){
				settings.succ(JSON.parse(ajax.responseText));
			}
			if(settings.dataType == 'xml'){
				settings.succ(ajax.responseXML);
			}
			if(settings.dataType == 'str'){
				settings.succ(ajax.responseText);
			}
		}else{
			settings.fail(ajax.responseText);
		}
	}

	
}
