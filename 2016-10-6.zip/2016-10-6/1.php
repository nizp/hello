<?php
$ymjz = file_get_contents('http://www.kaola.com/activity/brandStreet/category.html?id=2015121015AC04538912');
echo $ymjz;

